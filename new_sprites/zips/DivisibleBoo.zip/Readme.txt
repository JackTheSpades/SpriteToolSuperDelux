made by anonimzwx

Credits not required.

It use the same palette of the common Boos

It Use SP4 = GFX11 for Boo Graphics and SP1 = GFX00 for smoke.